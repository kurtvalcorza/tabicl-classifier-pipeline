"""TIC / TICA probes: exec the TabICLv2 classifier notebooks' own cells torch-free.

usage: python run_probes_tic.py <repo checkout> <out dir>
"""
from __future__ import annotations
import hashlib, io, json, os, shutil, sys, tempfile, types, urllib.request, zipfile
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent))
import harness as H

REPO = Path(sys.argv[1]).resolve(); OUT = Path(sys.argv[2]).resolve(); OUT.mkdir(parents=True, exist_ok=True)
E2E = REPO / "tutorials/tabiclv2_classifier_colab.ipynb"
AI = REPO / "tutorials/tabiclv2_classifier_artifact_inference_colab.ipynb"
RESULTS = {}

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

class StandInTabICLClassifier:
    """scikit-learn stand-in with TabICLClassifier's fit/predict/predict_proba/classes_ surface (NOT the model).
    The checkpoint file is opened and hashed so a missing checkpoint fails like the real loader would."""
    def __init__(self, model_path=None, **kw):
        self.model_path = model_path; self.kw = kw
    def fit(self, X, y):
        Path(self.model_path).read_bytes()
        Xn = np.asarray(X, dtype=float)  # TabICL receives encoded numeric features; object columns fail here
        self._m = make_pipeline(SimpleImputer(), StandardScaler(), LogisticRegression(max_iter=3000)).fit(Xn, np.asarray(y))
        self.classes_ = self._m.classes_; return self
    def predict_proba(self, X):
        return self._m.predict_proba(np.asarray(X, dtype=float))
    def predict(self, X):
        return self._m.predict(np.asarray(X, dtype=float))

tabicl = types.ModuleType("tabicl"); tabicl.TabICLClassifier = StandInTabICLClassifier
tabicl.FinetunedTabICLClassifier = lambda **kw: (_ for _ in ()).throw(RuntimeError("fine-tuning not available in the stand-in"))
sys.modules["tabicl"] = tabicl
torch = H.install_stub_modules({"tabicl": "2.1.1"}); torch.__version__ = "2.14.0+standin"

E2E_CELLS, e2e_nb = H.code_cells(E2E)
AI_CELLS, ai_nb = H.code_cells(AI)
CARRIED = [5]

def fresh_ns(workdir):
    os.chdir(workdir)
    mod = types.ModuleType("__nbprobe__"); sys.modules["__nbprobe__"] = mod; ns = mod.__dict__
    os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
    steps = [H.run_cell(ns, E2E_CELLS[i], i) for i in [3] + CARRIED]
    os.environ.pop("DIMER_NOTEBOOK_CI_PREINSTALLED")
    assert all(s["ok"] for s in steps), steps
    w = Path(workdir) / "weights" / ns["BASE_CHECKPOINT_NAME"]; w.parent.mkdir(exist_ok=True); w.write_bytes(b"stand-in checkpoint")
    P = ns["TabICLClassificationPipeline"]
    ns["pipe"] = P(ns["create_classifier"](model_path=w, n_estimators=8, random_state=42, device="cpu"), model_path=w, n_estimators=8, random_state=42, device="cpu")
    return ns

def set_form(src, name, value):
    lines = src.split("\n")
    for k, line in enumerate(lines):
        if line.startswith(f"{name} = "):
            comment = line[line.index("#"):] if "#" in line else ""
            lines[k] = f"{name} = {value!r}  {comment}"; return "\n".join(lines)
    raise KeyError(name)

E2E_STAGES = [9, 11, 13, 15, 17, 19]
def e2e_run(workdir, forms=None, uploads=()):
    c = H.Colab(); c.queue.extend(uploads)
    ns = fresh_ns(workdir); steps = []
    for i in E2E_STAGES:
        src = E2E_CELLS[i]
        for (cell, name), value in (forms or {}).items():
            if cell == i: src = set_form(src, name, value)
        s = H.run_cell(ns, src, i); steps.append(s)
        if not s["ok"]: break
    H.Colab.remove()
    last = steps[-1]
    return ns, {"cells_ok": [s["cell"] for s in steps if s["ok"]], "stopped_in_cell": None if last["ok"] else last["cell"], "error": last.get("error")}

def tail(s, n=600):
    return s[-n:]

# P1 default
wd = Path(tempfile.mkdtemp(prefix="tic_p1_")); ns, r = e2e_run(wd)
if r["stopped_in_cell"] is None:
    r.update(split={"train": len(ns["train_encoded"]), "holdout": len(ns["holdout_encoded"]), "test": len(ns["test_encoded"])},
             majority_class_baseline=ns["baseline"], findings=ns["input_manifest"]["findings"],
             outputs=sorted(os.listdir(wd / "outputs")), zip_sha256=H.sha256(wd / "outputs/tabiclv2_classifier_artifact.zip"),
             zip_members=sorted(zipfile.ZipFile(wd / "outputs/tabiclv2_classifier_artifact.zip").namelist()),
             stand_in_holdout_metrics_not_model_evidence=ns["active_metrics"],
             classical_holdout=ns["classical"], blend=ns["report"]["blend_holdout"],
             predictions_rows_are_holdout=True)
RESULTS["P1_e2e_default_standin"] = r
E2E_WD, E2E_NS = wd, ns

# P2 baselines on the notebook's own partitions (independent of the stand-in)
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score
from sklearn.ensemble import RandomForestClassifier
from lightgbm import LGBMClassifier
from sklearn.model_selection import train_test_split
tr, ho, te = ns["train_encoded"], ns["holdout_encoded"], ns["test_encoded"]; F, T = ns["FEATURE_COLUMNS"], ns["TARGET_COLUMN"]
p2 = {"partitions": "the notebook's stratified 60/20/20 (random_state=42)", "rows": [len(tr), len(ho), len(te)], "one_row_resolution": [round(1/len(ho), 4), round(1/len(te), 4)], "models": {}}
for name, m in {"logistic_regression(std)": make_pipeline(StandardScaler(), LogisticRegression(max_iter=5000)),
                "lightgbm(100, seed 42)": LGBMClassifier(random_state=42, n_estimators=100, verbose=-1),
                "random_forest(100, seed 42)": RandomForestClassifier(random_state=42, n_estimators=100)}.items():
    m.fit(tr[F], tr[T]); rec = {}
    for part, d in (("holdout", ho), ("test", te)):
        pr = m.predict_proba(d[F]); cl = list(m.classes_)
        rec[part] = {"accuracy": round(accuracy_score(d[T], m.predict(d[F])), 4), "log_loss": round(log_loss(d[T], pr, labels=cl), 4),
                     "roc_auc": round(roc_auc_score((d[T] == "malignant").astype(int), pr[:, cl.index("malignant")]), 4), "errors": int((m.predict(d[F]) != d[T]).sum())}
    p2["models"][name] = rec
p2["notebook_prose_previous_revision_tabicl"] = {"holdout_accuracy": 0.974, "test_accuracy": 0.956, "holdout_log_loss": 0.038, "test_log_loss": 0.085, "holdout_roc_auc": 0.9997, "test_roc_auc": 0.995, "majority": 0.63}
RESULTS["P2_baselines"] = p2

# P3 other samples and BYOD
p3 = {}
nsw, rw = e2e_run(Path(tempfile.mkdtemp()), {(9, "DATA_SOURCE"): "Sample: Wine"})
if rw["stopped_in_cell"] is None: rw["split"] = [len(nsw["train_encoded"]), len(nsw["holdout_encoded"]), len(nsw["test_encoded"])]
p3["sample_wine"] = rw
nsp, rp = e2e_run(Path(tempfile.mkdtemp()), {(9, "DATA_SOURCE"): "Sample: Palmer Penguins"})
if rp["stopped_in_cell"] is None:
    rp["split"] = [len(nsp["train_encoded"]), len(nsp["holdout_encoded"]), len(nsp["test_encoded"])]; rp["encoded_categoricals"] = sorted(nsp["CATEGORICAL_ENCODERS"])
    rp["archive_sha256_verified_by_cell"] = True
p3["sample_palmer_penguins_live_fetch"] = rp
base = ns["frame"].copy()
def up(df, name="mine.csv"): return {name: df.to_csv(index=False).encode()}
byod = {}
good = base.copy(); good.insert(0, "site_id", [f"S{i % 7}" for i in range(len(good))])
byod["upload_csv_good"] = ({(9, "DATA_SOURCE"): "Upload CSV", (9, "USE_BYOD"): True}, [up(good)])
miss = base.copy(); miss["target"] = miss["target"].astype(object); miss.loc[miss.index[:7], "target"] = None
byod["upload_csv_7_missing_targets"] = ({(9, "DATA_SOURCE"): "Upload CSV", (9, "USE_BYOD"): True}, [up(miss)])
tr_m = miss.iloc[:400]; va_m = miss.iloc[400:]
byod["presplit_7_missing_targets_in_train"] = ({(9, "DATA_SOURCE"): "Upload pre-split train/val/test", (9, "USE_BYOD"): True}, [{"train.csv": tr_m.to_csv(index=False).encode(), "val.csv": va_m.to_csv(index=False).encode()}])
strnum = base.copy(); strnum["mean radius"] = strnum["mean radius"].astype(object); strnum.loc[strnum.index[0], "mean radius"] = "abc"
byod["upload_csv_stray_string_in_numeric_feature"] = ({(9, "DATA_SOURCE"): "Upload CSV", (9, "USE_BYOD"): True}, [up(strnum)])
byod["upload_csv_target_named_differently"] = ({(9, "DATA_SOURCE"): "Upload CSV", (9, "USE_BYOD"): True}, [up(base.rename(columns={"target": "diagnosis"}))])
byod["upload_csv_40_rows"] = ({(9, "DATA_SOURCE"): "Upload CSV", (9, "USE_BYOD"): True}, [up(base.groupby("target").head(20))])
byod["presplit_val_with_unseen_class"] = ({(9, "DATA_SOURCE"): "Upload pre-split train/val/test", (9, "USE_BYOD"): True}, [{"train.csv": base.iloc[:400].to_csv(index=False).encode(), "val.csv": base.iloc[400:].assign(target=lambda d: d["target"].where(d.index % 10 != 0, "other")).to_csv(index=False).encode()}])
byod["use_byod_with_sample_source"] = ({(9, "USE_BYOD"): True}, [])
byod["upload_source_without_use_byod"] = ({(9, "DATA_SOURCE"): "Upload CSV"}, [])
for name, (forms, uploads) in byod.items():
    nsb, rb = e2e_run(Path(tempfile.mkdtemp()), forms, uploads)
    if "input_manifest" in nsb:
        rb["manifest_train_rows"] = nsb["input_manifest"]["inputs"][0]["rows"]
        rb["manifest_dropped_missing_target_rows"] = nsb["input_manifest"]["inputs"][0].get("dropped_missing_target_rows")
    if "CATEGORICAL_ENCODERS" in nsb: rb["encoded_categoricals"] = sorted(nsb["CATEGORICAL_ENCODERS"])
    if rb["stopped_in_cell"] is None and "dropped_train" in nsb: rb["cell11_dropped_print"] = {"train": nsb["dropped_train"], "holdout": nsb["dropped_holdout"]}
    p3[name] = rb
outside = H.run_cell(fresh_ns(Path(tempfile.mkdtemp())), set_form(set_form(E2E_CELLS[9], "DATA_SOURCE", "Upload CSV"), "USE_BYOD", True), 9)
p3["upload_csv_outside_colab"] = {"ok": outside["ok"], "error": outside.get("error")}
RESULTS["P3_samples_and_byod"] = p3

# P4 new-data inference branch and re-runs
p4 = {}
nd = base.drop(columns="target").head(5).copy(); nd["record_id"] = list("abcde"); ndp = E2E_WD / "new.csv"; nd.to_csv(ndp, index=False)
nsn, rn = e2e_run(Path(tempfile.mkdtemp()), {(17, "RUN_NEW_DATA_INFERENCE"): True, (17, "NEW_DATA_PATH"): str(ndp)})
if rn["stopped_in_cell"] is None: rn["prediction_columns"] = list(pd.read_csv(Path(os.getcwd()) / "outputs/tabiclv2_classifier_predictions.csv").columns)[-4:]
p4["new_data_by_path_with_id_column"] = rn
again = [H.run_cell(E2E_NS, E2E_CELLS[i], i) for i in [9, 11, 13, 15, 17, 19]]
p4["rerun_sections_4_to_9_same_kernel"] = {"all_ok": all(s["ok"] for s in again), "errors": [s.get("error") for s in again if not s["ok"]]}
RESULTS["P4_new_data_and_reruns"] = p4

# P5 companion contract
ZIP = E2E_WD / "outputs/tabiclv2_classifier_artifact.zip"
def ai_run(workdir, zip_path="", new_path="", expected="", uploads=(), colab=True):
    c = H.Colab() if colab else None
    if c: c.queue.extend(uploads)
    nsa = fresh_ns(workdir); steps = []
    for i in [9, 11, 13, 15]:
        src = AI_CELLS[i]
        if i == 9: src = set_form(set_form(src, "ARTIFACT_ZIP_PATH", str(zip_path)), "EXPECTED_ZIP_SHA256", expected)
        if i == 13: src = set_form(src, "NEW_DATA_PATH", str(new_path))
        s = H.run_cell(nsa, src, i); steps.append(s)
        if not s["ok"]: break
    if c: H.Colab.remove()
    last = steps[-1]
    return nsa, {"cells_ok": [s["cell"] for s in steps if s["ok"]], "stopped_in_cell": None if last["ok"] else last["cell"], "error": last.get("error")}
p5 = {}
wd5 = Path(tempfile.mkdtemp(prefix="tic_ai_"))
rows8 = E2E_NS["holdout_data"][E2E_NS["FEATURE_COLUMNS"]].head(8); unl = wd5 / "new_rows.csv"; rows8.to_csv(unl, index=False)
nsa, r = ai_run(wd5, ZIP, unl, expected=H.sha256(ZIP))
if r["stopped_in_cell"] is None:
    pe = pd.read_csv(E2E_WD / "outputs/tabiclv2_classifier_predictions.csv"); pa = pd.read_csv(wd5 / "outputs/tabiclv2_classifier_artifact_inference_predictions.csv")
    r["companion_equals_e2e"] = bool((pe["prediction"] == pa["prediction"]).all() and np.allclose(pe.filter(like="probability_"), pa.filter(like="probability_"), rtol=1e-5, atol=1e-7))
    r["outputs"] = sorted(os.listdir(wd5 / "outputs")); r["evaluation_report_sample_kind"] = nsa["report"]["sample_kind"]
p5["e2e_zip_plus_unlabelled_rows_with_expected_sha"] = r
p5["e2e_predictions_csv_as_new_input"] = ai_run(Path(tempfile.mkdtemp()), ZIP, E2E_WD / "outputs/tabiclv2_classifier_predictions.csv")[1]
p5["zip_by_path_rows_by_upload"] = ai_run(Path(tempfile.mkdtemp()), ZIP, "", uploads=[{"new_rows.csv": unl.read_bytes()}])[1]
p5["default_both_empty_outside_colab"] = ai_run(Path(tempfile.mkdtemp()), colab=False)[1]
p5["default_both_empty_colab_nothing_supplied"] = ai_run(Path(tempfile.mkdtemp()))[1]
p5["wrong_expected_sha"] = ai_run(Path(tempfile.mkdtemp()), ZIP, unl, expected="0" * 64)[1]
def rezip(mutator, name):
    d = Path(tempfile.mkdtemp()) / "b"; zipfile.ZipFile(ZIP).extractall(d); mutator(d)
    out = Path(tempfile.mkdtemp()) / name
    with zipfile.ZipFile(out, "w") as z:
        for p in sorted(d.rglob("*")):
            if p.is_file(): z.write(p, p.relative_to(d).as_posix())
    return out
def evil_member(z):
    pass
trav = Path(tempfile.mkdtemp()) / "trav.zip"
with zipfile.ZipFile(trav, "w") as z:
    z.writestr("../evil.txt", "x"); z.writestr("artifact.json", "{}")
p5["zip_with_traversal_member"] = ai_run(Path(tempfile.mkdtemp()), trav, unl)[1]
def extra_file(d): (d / "notes.txt").write_text("hi")
p5["unlisted_extra_member"] = ai_run(Path(tempfile.mkdtemp()), rezip(extra_file, "extra.zip"), unl)[1]
def tamper_ctx(d):
    p = d / "training_context.parquet"; p.write_bytes(p.read_bytes() + b"x")
p5["tampered_context"] = ai_run(Path(tempfile.mkdtemp()), rezip(tamper_ctx, "tamper.zip"), unl)[1]
def other_base(d):
    m = json.loads((d / "artifact.json").read_text()); m["baseModelRevision"] = "0" * 40; (d / "artifact.json").write_text(json.dumps(m))
p5["other_base_revision"] = ai_run(Path(tempfile.mkdtemp()), rezip(other_base, "base.zip"), unl)[1]
def swap_ckpt(d):
    c = d / "checkpoints/best.ckpt"; c.write_bytes(b"a different checkpoint the manifest still calls pretrained")
    m = json.loads((d / "artifact.json").read_text()); m["digests"]["checkpointSha256"] = H.sha256(c); m["sizes"]["checkpoint"] = c.stat().st_size
    (d / "artifact.json").write_text(json.dumps(m))
nss, rs = ai_run(Path(tempfile.mkdtemp()), rezip(swap_ckpt, "swap.zip"), unl)
rs["manifest_mode"] = "pretrained"; rs["checkpoint_digest_equals_base"] = False
p5["checkpoint_swapped_manifest_rehashed_mode_pretrained"] = rs
def old_torch(d):
    m = json.loads((d / "artifact.json").read_text()); m["runtime"]["torchVersion"] = "2.11.0"; (d / "artifact.json").write_text(json.dumps(m))
p5["producer_torch_2_11"] = ai_run(Path(tempfile.mkdtemp()), rezip(old_torch, "torch.zip"), unl)[1]
bad = rows8.copy(); bad["mean radius"] = bad["mean radius"].astype(object); bad.iloc[0, 0] = "abc"; bp = wd5 / "bad.csv"; bad.to_csv(bp, index=False)
p5["non_numeric_value_in_numeric_feature"] = ai_run(Path(tempfile.mkdtemp()), ZIP, bp)[1]
ex = rows8.copy(); ex["record_id"] = range(8); ep = wd5 / "ex.csv"; ex.to_csv(ep, index=False)
nse, re_ = ai_run(Path(tempfile.mkdtemp()), ZIP, ep)
if re_["stopped_in_cell"] is None: re_["record_id_kept"] = "record_id" in nse["out"].columns
p5["identifier_column_kept"] = re_
mi = rows8.drop(columns=["mean radius"]); mp = wd5 / "mi.csv"; mi.to_csv(mp, index=False)
p5["missing_feature"] = ai_run(Path(tempfile.mkdtemp()), ZIP, mp)[1]
RESULTS["P5_artifact_contract"] = p5

# P6 install guard with Colab's recorded preloaded versions
import importlib.metadata as md, subprocess as sp
real_run, real_ver = sp.run, md.version; state = {"installed": False}
sp.run = lambda *a, **k: state.update(installed=True)
md.version = lambda d: ("2.5.2" if state["installed"] else "2.1.3") if d == "numpy" else real_ver(d)
import numpy
try:
    g = H.run_cell({"__name__": "__guard__"}, E2E_CELLS[3].split("\nimport torch, numpy")[0], 3)
finally:
    sp.run, md.version = real_run, real_ver
RESULTS["P6_install_guard_preloaded_numpy"] = {"simulated": "numpy loaded=2.1.3 (Colab T4, 2026-09-27 fleet record), pin numpy==2.5.2; pip replaced by a no-op", "ok": g["ok"], "error": g.get("error")}

# P7 static
p7 = {}
for label, (cells, nb) in (("e2e", (E2E_CELLS, e2e_nb)), ("companion", (AI_CELLS, ai_nb))):
    md_text = "\n".join("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "markdown")
    p7[label] = {"cells": len(nb["cells"]), "code_cells": len(cells), "carried_lines": "".join(nb["cells"][5]["source"]).count("\n") + 1,
                 "guided_markers": {k: (k.lower() in md_text.lower()) for k in ["How to use", "Roadmap", "Glossary", "What to notice", "Check your", "Troubleshoot", "Infrastructure", "Expected result"]},
                 "cellView_form_cells": sum(1 for c in nb["cells"] if c.get("metadata", {}).get("cellView") == "form"),
                 "restart_instruction_present": "Restart the runtime" in "".join(cells.values())}
RESULTS["P7_static"] = p7
text = json.dumps(RESULTS, indent=2, default=str).replace(tempfile.gettempdir(), "<tmp>")
(OUT / "results.json").write_text(text); print("written", OUT / "results.json")
